# abkhazia-info

Educational GitHub Pages site about historical and structural aspects of organized crime in Abkhazia.

## What is included
- `index.html` — English homepage
- `index_ru.html` — Russian homepage
- `styles.css` — shared stylesheet
- `README.md` — this file
- `LICENSE` — MIT license

## How to publish on GitHub Pages (simple)
1. Create a new repository on GitHub (for example `abkhazia-info`) and make it public.
2. Upload all files from this project (you can drag & drop the files on the GitHub web UI).
3. Open **Settings → Pages** and set source to branch **main** (or `main`/`root`).
4. Save. The site will be available at `https://<your-username>.github.io/abkhazia-info/`.

## Legal and editorial guidance
- This resource is educational. Do **not** publish accusations about private individuals without legal confirmation.
- Prefer official documents, court records, press releases, academic research, and reputable media with dates.
- Add a contact and correction request mechanism on the site before publishing potentially sensitive information.
- Consult a lawyer in your jurisdiction if you plan to publish biographies or critical content about named individuals.

